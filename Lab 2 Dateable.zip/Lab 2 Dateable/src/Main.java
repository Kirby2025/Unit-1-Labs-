import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // Creating Scanner Object
        Scanner sc = new Scanner(System.in);

        // Prompting User for Input
        System.out.println("Enter your age: ");
        int age = sc.nextInt();

        // Calculating Minimum Age
        int minAge = age/2 + 7;

        // Printing Result
        System.out.println(age + "-year olds should date somebody who is at least " + minAge + " years old.");
    }
}